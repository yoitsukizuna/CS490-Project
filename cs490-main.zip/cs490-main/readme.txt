==========MILESTONE ALPHA=========
2021-06-03
*user can register and login, landing to dashboard
*login as admin, pw admin1234 direct to admin page

*to be improved:
    --have bugs when trying to implement flask_security
    --admin page needs to be hide from normal users
    --have bugs dealing with datastore
    --UI implement


For the next stage:
==========MILESTONE BETA=========
*improve dashboard:
    --add friend list
    --add post query
*Post function:
    --search posts
    --search users  --user public profile page
    --make new posts
    --make comments
*chat function:
    --real time chat function
*add flask_security
